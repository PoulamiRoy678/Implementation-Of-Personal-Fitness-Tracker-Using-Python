import pandas as pd

df=pd.read_csv(r'D:/app.py/simple_calories_dataset.csv')

print(df)
