import pandas as pd

df=pd.read_csv(r'D:/app.py/exercise.csv')

print(df)
